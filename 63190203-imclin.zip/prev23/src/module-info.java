/**
 * Compiler for PREV'23 programming language producing MMIX assembly code.
 */
module prev23 {
	requires java.xml;
	requires antlr;
}