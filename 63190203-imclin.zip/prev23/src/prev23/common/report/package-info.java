/**
 * Infrastructure for generating reports.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package prev23.common.report;