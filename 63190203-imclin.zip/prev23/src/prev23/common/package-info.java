/**
 * Code used by all compiler phases.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package prev23.common;