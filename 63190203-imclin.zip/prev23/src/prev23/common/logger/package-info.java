/**
 * Infrastructure for generating logs relating of individual compiler phases.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package prev23.common.logger;