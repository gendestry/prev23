/**
 * The PREV'23 compiler.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package prev23;