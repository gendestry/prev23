/**
 * Syntax analysis.
 */
package prev23.phase.synan;
