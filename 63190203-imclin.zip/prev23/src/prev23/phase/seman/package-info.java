/**
 * Semantic analysis.
 */
package prev23.phase.seman;
