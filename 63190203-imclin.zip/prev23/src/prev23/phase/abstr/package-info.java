/**
 * Abstract syntax tree construction.
 */
package prev23.phase.abstr;