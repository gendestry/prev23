/**
 * Lexical analysis.
 */
package prev23.phase.lexan;
