/**
 * Intermediate code generation.
 */
package prev23.phase.imcgen;
