/**
 * Intermediate code linearization.
 */
package prev23.phase.imclin;