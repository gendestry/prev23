/**
 * Abstract syntax tree attributes.
 */
package prev23.data.ast.attribute;
