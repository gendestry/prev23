/**
 * Abstract syntax tree visitor.
 */
package prev23.data.ast.visitor;
