package prev23.data.ast.tree;

/**
 * A name.
 */
public interface AstName extends AstTree {

}
