package prev23.data.ast.tree.decl;

import prev23.data.ast.tree.*;

/**
 * Abstract declaration.
 */
public interface AstDecl extends AstTree {

}
