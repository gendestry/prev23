/**
 * Abstract syntax tree: representing declarations.
 */
package prev23.data.ast.tree.decl;
