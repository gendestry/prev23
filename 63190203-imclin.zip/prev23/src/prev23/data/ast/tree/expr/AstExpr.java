package prev23.data.ast.tree.expr;

import prev23.data.ast.tree.*;

/**
 * Abstract expression.
 */
public interface AstExpr extends AstExec {

}
