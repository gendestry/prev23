/**
 * Abstract syntax tree: representing types.
 */
package prev23.data.ast.tree.type;
