package prev23.data.ast.tree.type;

import prev23.data.ast.tree.*;

/**
 * Abstract type.
 */
public interface AstType extends AstTree {

}
