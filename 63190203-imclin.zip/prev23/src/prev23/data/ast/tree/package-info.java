/**
 * Abstract syntax tree.
 */
package prev23.data.ast.tree;
