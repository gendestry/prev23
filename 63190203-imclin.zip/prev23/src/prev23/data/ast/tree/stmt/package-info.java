/**
 * Abstract syntax tree: representing statements.
 */
package prev23.data.ast.tree.stmt;
