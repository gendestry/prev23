package prev23.data.ast.tree.stmt;

import prev23.data.ast.tree.*;

/**
 * Abstract statement.
 */
public interface AstStmt extends AstExec {

}
