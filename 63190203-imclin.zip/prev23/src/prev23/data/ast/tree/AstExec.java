package prev23.data.ast.tree;

/**
 * An executable part of the abstract syntax tree.
 */
public interface AstExec extends AstTree {

}
