/**
 * Memory layout: frames and accesses.
 */
package prev23.data.mem;
