/**
 * Visitors for traversing intermediate code trees.
 */
package prev23.data.imc.visitor;
