package prev23.data.imc.code.expr;

import prev23.data.imc.code.*;

/**
 * Intermediate code instruction denoting an expression.
 */
public abstract class ImcExpr extends ImcInstr {
}
