/**
 * Intermediate code instructions denoting expressions.
 */
package prev23.data.imc.code.expr;
