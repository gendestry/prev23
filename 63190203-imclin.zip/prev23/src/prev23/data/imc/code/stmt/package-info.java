/**
 * Intermediate code instructions denoting statements.
 */
package prev23.data.imc.code.stmt;
