/**
 * Intermediate code instructions.
 */
package prev23.data.imc.code;
