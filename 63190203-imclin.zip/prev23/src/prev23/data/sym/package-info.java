/**
 * Lexical symbols.
 */
package prev23.data.sym;