/**
 * Representing types.
 */
package prev23.data.typ;