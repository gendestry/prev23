/**
 * Chucks of linear intermediate code.
 */
package prev23.data.lin;
