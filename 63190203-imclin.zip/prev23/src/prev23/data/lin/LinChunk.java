package prev23.data.lin;

/**
 * An abstract chunk of linear code.
 */
public class LinChunk {
}
